POORVIKA SPECIAL — 5 PAGE WEBSITE
Files: index.html, memories.html, sorry.html, promises.html, final.html, style.css, script.js

GITHUB PAGES UPDATE:
1. Open your repository: shivanshu056/poorvika-special-surprise
2. Open Add file > Upload files.
3. Upload ALL 7 website files from this folder (not the folder itself).
4. If GitHub asks to replace index.html/style.css/script.js, choose commit changes.
5. Settings > Pages > Deploy from branch > main > /(root), then Save.
6. Wait 1-3 minutes and open:
https://shivanshu056.github.io/poorvika-special-surprise/

The site is mobile-friendly. The music button is a visual toggle (no audio file is included).
